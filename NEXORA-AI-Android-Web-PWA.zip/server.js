const http=require('http'),fs=require('fs'),path=require('path');
const PORT=process.env.PORT||3000;
const system=`You are NEXORA AI, a warm, capable, human-like conversational AI assistant. Speak naturally, without pretending to be human. Answer clearly and accurately. Ask clarifying questions when necessary. Help with coding, learning, creative writing, planning and general questions. Be honest about uncertainty and capabilities. Never claim to have performed actions you haven't performed.`;
const server=http.createServer(async(req,res)=>{
  if(req.method==='POST'&&req.url==='/api/chat'){
    let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>100000){res.writeHead(413);res.end('Too large');return;}}
    let body;try{body=JSON.parse(raw)}catch{res.writeHead(400);res.end('Invalid JSON');return}
    if(!process.env.OPENAI_API_KEY){res.writeHead(503,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'AI not configured. Set OPENAI_API_KEY on the server.'}));return}
    const messages=(Array.isArray(body.messages)?body.messages:[]).filter(m=>['user','assistant'].includes(m.role)&&typeof m.content==='string').slice(-24).map(m=>({role:m.role,content:m.content.slice(0,8000)}));
    if(!messages.length){res.writeHead(400);res.end('No messages');return}
    try{const r=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4o-mini',messages:[{role:'system',content:system},...messages]})});const data=await r.json();if(!r.ok)throw Error(data.error?.message||'AI service error');res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({reply:data.choices?.[0]?.message?.content||'No response returned.'}));}catch(e){res.writeHead(502,{'Content-Type':'application/json'});res.end(JSON.stringify({error:e.message}))}return;
  }
  const url=req.url==='/'?'/index.html':decodeURIComponent(req.url.split('?')[0]);const base=path.resolve(__dirname,'public');const target=path.resolve(base,'.'+url);if(!target.startsWith(base+path.sep)){res.writeHead(403);res.end();return}fs.readFile(target,(err,data)=>{if(err){res.writeHead(404);res.end('Not found');return}res.writeHead(200,{'Content-Type':({'.html':'text/html; charset=utf-8','.js':'text/javascript','.webmanifest':'application/manifest+json','.png':'image/png','.css':'text/css'}[path.extname(target)]||'application/octet-stream')});res.end(data)});
});server.listen(PORT,()=>console.log(`NEXORA AI running at http://localhost:${PORT}`));
